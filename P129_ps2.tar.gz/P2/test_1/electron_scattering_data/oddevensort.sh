#! /bin/bash
EVEN_FILES="./*[02468].bin"
ODD_FILES="./*[13579].bin"

mkdir even odd

for f in $EVEN_FILES
do
    echo "Processing file $f"
    mv $f ./even
done

for f in $ODD_FILES
do
    echo "Processing file $f"
    mv $f ./odd
done