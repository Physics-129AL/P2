#! /bin/bash
file_remove(){ rm $1/*; }
# When I run this in the script, the command line doesn't seem to know about it, but
# when I type it in the command line directly, then I can call the function later.