# ! /bin/bash
rm "$1"/*