#! /bin/bash

num1=$1
echo "Input: " $num1

declare -a hexval=(
    [0]="0"
    [1]="1"
    [2]="2"
    [3]="3"
    [4]="4"
    [5]="5"
    [6]="6"
    [7]="7"
    [8]="8"
    [9]="9"
    [10]="A"
    [11]="B"
    [12]="C"
    [13]="D"
    [14]="E"
    [15]="F"
    [16]="10"
    [26]="1A"
    [31]="1F"
    [32]="20"
)

declare -a binval=(
    [0]="0"
    [1]="1"
)

find_hex(){
    in_num="$1"

    if [[ $in_num -gt 100000 ]] ; then
        echo "Error: $in_num is too big. Try again."
        return
    fi

    my_quo=$in_num
    my_rem=0
    my_hex=""
    i=0
    while [[ $my_quo > 0 && $i < 20 ]];
    do
        my_rem=$((my_quo % 16))
        tmp_str=${hexval[my_rem]}

        tmp_str+="${hex_str}"

        hex_str=$tmp_str
        
        my_quo=$((my_quo / 16))

        i+=1
    done

    echo $hex_str  
}

find_bin(){
    in_num="$1"

    if [[ $in_num -gt 100000 ]]; then
        echo "Error: $in_num is too big. Try again."
        return 0
    fi
    
    my_quo=$in_num
    my_rem=0
    my_bin=""
    i=0
    while [[ $my_quo > 0 && $i < 40 ]];
    do
        my_rem=$((my_quo % 2))
        tmp_str=${binval[my_rem]}

        tmp_str+="${bin_str}"

        bin_str=$tmp_str

        my_quo=$((my_quo / 2))

        i+=1
    done
        
    echo $bin_str
}

echo "Hexadecimal conversion:"
find_hex $num1

echo "Binary conversion:"
find_bin $num1