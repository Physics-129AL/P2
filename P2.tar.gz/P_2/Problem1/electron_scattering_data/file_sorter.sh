#! /bin/bash

# Create our directories for the odd and even files that we are to sort out
#mkdir -p odd
#mkdir -p even

#for file in electron_scattering_data/*; do
	# Check if our file is a regular file
	#if [ -f "$file" ]; then
		# If our file is a regular file, then we consider its name
		#filename=$(basename "$file")
		# Files with an odd name are moved to the odd subdirectory
		#if [[ $filename == *1.bin* || $filename == *3.bin* || $filename == *5.bin* || $filename == 7.bin* || $filename == *9.bin* ]]; then 
		    #mv "$file" odd/
		# All other files are moved to the even subdirectory    
	    	#else
	    	    #mv "$file" odd/
		#fi
	#fi
#done	
			
# Create our directories for the odd and even files that we are to sort out
mkdir -p odd
mkdir -p even

# Move odd files, which include 1.bin, 3.bin, 5.bin, etc. to the odd subdirectory
mv ./*1.bin* ./odd/
mv ./*3.bin* ./odd/
mv ./*5.bin* ./odd/
mv ./*7.bin* ./odd/
mv ./*9.bin* ./odd/

# Move even files. which include 0.bin, 2.bin, 4.bin, etc. to the even subdirectory
mv ./*0.bin* ./even/
mv ./*2.bin* ./even/
mv ./*4.bin* ./even/
mv ./*6.bin* ./even/
mv ./*8.bin* ./even/
