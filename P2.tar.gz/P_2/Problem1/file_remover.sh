#! /bin/bash

# Create a function that deletes all the files in a directory specificed by a user
#file_remove() {
	# Take user input for the variable directory_name
	#read -p "Enter the directory name: " directory_name

	# Find the specified directory in the current directory
	#directories=($(find ./ -type d -name "directory_name"))
	
	# If the specified directory is not found in the current directory, then return a message that states this to the user
	#if [ ${#directories[@]} -eq 0 ]; then
		#echo "Directory '$directory_name' is not found within the current directory. Please navigate to the correct directory and try again."	
	# If the specified directory is found, then clear all the files in it and return a message that states the completion of this task to the user
	#else
		#rm -f "directory_path"/*
		#echo "All files in 'directory_name' have been removed."
	#fi
#}

#file_remove

# Create a function that deletes all the files in a directory specificed by a user
file_remove() {
        # Take user input for the variable directory_name
        read -p "Enter the directory name: " directory_name
	# look through all of the directories in the current directory to see if any match the input. if matches are found, then we delete all the files in them, and report this to the user
	for directory in */; do
		if [ -d "$directory" ] && [ "$directory" == "$directory_name/" ]; then
			rm -f "$directory"*
			echo "All files in '$directory' have been removed."
			return
		fi
	done
	# If the specified directory is not found within the current directory, report this to the user
	echo "Directory '$directory_name' is not found within the current directory. Please navigate to the correct directory and try again."  

}	

file_remove
