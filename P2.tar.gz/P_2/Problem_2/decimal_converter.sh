#! /bin/bash

# Perform the series of divisions
read -p "Enter a decimal number to convert: " decimal_value

if [ "$decimal_value" -le 100000 ]; then
  base=16

  # Initialize converted values
  hexadecimal_value=""
  binary_value=""

  while [ $decimal_value -gt 0 ]; do
    remainder=$((decimal_value % base))

    # Map remainder to hexadecimal and binary values
    case $remainder in
      0) hex_digit="0"; bin_digit="0000";;
      1) hex_digit="1"; bin_digit="0001";;
      2) hex_digit="2"; bin_digit="0010";;
      3) hex_digit="3"; bin_digit="0011";;
      4) hex_digit="4"; bin_digit="0100";;
      5) hex_digit="5"; bin_digit="0101";;
      6) hex_digit="6"; bin_digit="0110";;
      7) hex_digit="7"; bin_digit="0111";;
      8) hex_digit="8"; bin_digit="1000";;
      9) hex_digit="9"; bin_digit="1001";;
      10) hex_digit="A"; bin_digit="1010";;
      11) hex_digit="B"; bin_digit="1011";;
      12) hex_digit="C"; bin_digit="1100";;
      13) hex_digit="D"; bin_digit="1101";;
      14) hex_digit="E"; bin_digit="1110";;
      15) hex_digit="F"; bin_digit="1111";;
      16) hex_digit="10"; bin_digit="00010000";;
      26) hex_digit="1A"; bin_digit="00011010";;
      31) hex_digit="1F"; bin_digit="00011111";;
      32) hex_digit="20"; bin_digit="00100000";;

	esac

    # Prepend digits to the values
    hexadecimal_value="${hex_digit}${hexadecimal_value}"
    binary_value="${bin_digit}${binary_value}"

    decimal_value=$((decimal_value / base))
  done

  echo "Decimal: $decimal_value"
  echo "Hexadecimal: 0x$hexadecimal_value"
  echo "Binary: $binary_value"
else
  echo "Decimal value must be 100,000 or less."
fi

done

